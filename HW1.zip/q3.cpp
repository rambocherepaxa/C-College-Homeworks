#include <iostream>
#include <cstring>
using namespace std;

char **divideWords(char *sentence, int count_of_words = 4);
char **duplicatedWords(char **devided_words, int count_of_words = 4);

int main()
{
    char sentence[] = "Ofek eat evry day";
    char **divided_words = divideWords(sentence);

    std::cout << "Devide function\n";
    for (int i = 0; divided_words[i] != nullptr; i++)
        cout << "Word " << i << ": " << divided_words[i] << endl;

    char **duplicated_words = duplicatedWords(divided_words, 4);
    
    std::cout << "Duplicate function\n";
    for (int i = 0; duplicated_words[i] != nullptr; i++)
    {
        cout << "Word " << i << ": " << duplicated_words[i] << endl;
        delete[] duplicated_words[i]; 
    }
    delete[] duplicated_words; 

    for (int i = 0; divided_words[i] != nullptr; i++)
        delete[] divided_words[i]; 
    delete[] divided_words; 
}

char **duplicatedWords(char **divided_words, int count_of_words)
{
    char **duplicated_words = new char *[count_of_words * 2];

    for (int i = 0; i < count_of_words; i++) {
        int word_length = strlen(divided_words[i]);
        duplicated_words[i] = new char[2 * word_length + 1];

        strcpy(duplicated_words[i], divided_words[i]); 
        strcat(duplicated_words[i], divided_words[i]); 

        duplicated_words[strlen(divided_words[i]) * 2 + 1] = nullptr; 
    }

    return duplicated_words;
}

char **divideWords(char *sentence, int count_of_words)
{
    char **words = new char *[count_of_words];
    char *current_word = new char[strlen(sentence) + 1]; // Выделяем память для текущего слова

    int word_index = 0, word_number = 0;

    for (int i = 0; sentence[i] != '\0'; i++)
    {
        if (sentence[i] != ' ')
        {
            current_word[word_index] = sentence[i];
            word_index++;
        }
        else
        {
            current_word[word_index] = '\0';               // Завершаем текущее слово нулевым символом
            words[word_number] = current_word; 
            word_number++;             // Сохраняем указатель на текущее слово в массив
            current_word = new char[strlen(sentence) + 1]; // Выделяем новую память для следующего слова

            word_index = 0;
        }
        std::cout << sentence[i] << std::endl;
    }

    current_word[word_index] = '\0'; // Завершаем последнее слово
    words[word_index] = current_word;
    words[word_index + 1] = nullptr; // Устанавливаем последний указатель в массиве на nullptr, чтобы знать, где заканчиваются слова

    return words;
}


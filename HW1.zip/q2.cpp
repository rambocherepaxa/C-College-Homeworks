#include <iostream>

using namespace std;

bool IsArithmeticProgression(int* arr, int size = 5);

int main(void)
{
    int* arr_p = NULL;
    arr_p =  new int[5];
    for (int i = 0; i < 5; i++)
        arr_p[i] = rand() % 10;//i + 2;


    if (IsArithmeticProgression(arr_p))
        std::cout << "Arithmetic progression" << std::endl;
    else
        std::cout << "Not arithmetic progression" << std::endl;

}

bool IsArithmeticProgression(int* arr, int size)
{
    int difference = arr[1] - arr[0];
    for (int i = 0; i < size - 1; i++)
    {
        if (arr[i] != arr[i + 1] - difference)
            return false;
    }
    return true;
}
#include <iostream>

using namespace std;

float WeightedAverage(float arr_1[], float arr_2[], float size = 4);

int main(void)
{
    float arr_1[] = {2,3,4,5};
    float arr_2[] = {0.2, 0.3, 0.4, 0.5}; 

    cout << "Average is: " << WeightedAverage(arr_1, arr_2) << endl;
}

float WeightedAverage(float arr_1[], float arr_2[], float size)
{
    float 
    avg_grades = 0,
    avg_weight = 0;
    
    for (int i = 0; i < size; i++){
        avg_grades += arr_1[i] * arr_2[i];
        avg_weight += arr_2[i];
    }
    return (avg_grades / avg_weight);
}
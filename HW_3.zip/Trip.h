#pragma once
#include <iostream>
#include <string>
#include "Date.h"

//condition ? result_if_true : result_if_false

class Trip
{
private:

	int _trip_number;
	std::string _trip_destination;
	Date _trip_date;

public:	
//_____________________________Methods_____________________________

	// Counstrator's

	Trip();
	Trip(int trip_number, std::string trip_destination, Date trip_date);

	// Getters
	int getTripNumber();
	std::string getTripDestination();
	Date getTripDate();

	// Setters
	void setTripNumber(int trip_number);
	void setTripDestination(std::string trip_destination);
	void setTripDate(Date trip_date);


	void PrintTrip();
};


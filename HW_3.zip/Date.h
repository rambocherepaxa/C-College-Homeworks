#pragma once
#include <iostream>
#include <string>

class Date
{
private:

	int _day = 0, _month = 0, _year = 0;

public:

	//_____________________________Methods_____________________________

// Counstrator's
	Date();
	Date(int day, int month, int year);
	~Date();


// Getters
	int getDay();
	int getMonth();
	int getYear();

// Setters
	void setDay(int day);
	void setMonth(int month);
	void setYear(int year);
	void printDate();

// Support methods
	bool isValidDate(int day, int month, int year);
	
};


#include "Trip.h"

Trip::Trip()
{
	this->_trip_number = 0;
    this->_trip_destination = "* NO TRIP DESTINATION *";
}

Trip::Trip(int trip_number, std::string trip_destination, Date trip_date)
{
    this->setTripNumber(trip_number);
    this->setTripDestination(trip_destination);
	this->setTripDate(trip_date);
}

int Trip::getTripNumber()
{
    return this->_trip_number;
}

std::string Trip::getTripDestination()
{
    return this->_trip_destination;
}

Date Trip::getTripDate()
{
    return this->_trip_date;
}

void Trip::setTripNumber(int trip_number)
{
    this->_trip_number = trip_number >= 1 ? trip_number : 0;
}

void Trip::setTripDestination(std::string trip_destination)
{
    this->_trip_destination = 
        trip_destination != "" ? trip_destination : "\n* NO TRIP DESTINATION *\n";
}

void Trip::setTripDate(Date trip_date)
{
    this->_trip_date.setDay(trip_date.getDay());
    this->_trip_date.setMonth(trip_date.getMonth());
    this->_trip_date.setYear(trip_date.getYear());
}

void Trip::PrintTrip()
{
	std::cout <<"\n__________________\n"<< std::endl;

	std::cout << "Number: " << this->getTripNumber() << std::endl;
    std::cout << "Destination: " << this->getTripDestination() << std::endl;
    std::cout << "Date: " <<
        this->_trip_date.getDay()  << ":" << 
        this->_trip_date.getMonth() << ":" <<
        this->_trip_date.getYear() << std::endl;

    std::cout << "\n_________________\n" << std::endl;
}

#include <iostream>
#include <string>
#include <vector>

#include "Date.h"
#include "Trip.h"

#define OPTION_PRINT_TRIPS 1
#define OPTION_EDIT_TRIP 2
#define OPTION_ADD_TRIP 3
#define OPTION_EXIT 4	

void printMenuOptions();
bool doesTripExist(std::vector<Trip>& trips, int tripId);

void printTrips(std::vector<Trip> trips_to_print);

// will accept vector of trips, and ask question: which trip you want to edit?
void editTrip(std::vector<Trip>& trips_to_edit);

// in main: addTrip(vector);
void addTrip(std::vector<Trip>& list_to_add_trip); // will create trip and add him to list


int main()
{
	int user_choice = 0;
	std::vector<Trip> trips;
	Date new_date;
	Trip new_trip;

	std::cout << "\n**Hello and Welcome to Trips manager program!**\n\n" <<
	"Here you can easily and comfortably manage your Trips database :)\n" <<
	"You have menu of options. Choose option for perform action you want. " << std::endl;

	while (user_choice != OPTION_EXIT)
	{
		printMenuOptions();
		std::cin >> user_choice;
		
		switch (user_choice)
		{
			case OPTION_PRINT_TRIPS:
				printTrips(trips);
				break;
			case OPTION_EDIT_TRIP:
				editTrip(trips);
				break;
			case OPTION_ADD_TRIP:
				addTrip(trips);
				break;
			case OPTION_EXIT:
				user_choice = OPTION_EXIT;	
				break;
	
			default:
				std::cout << "\nEnter number been 1-4!: ";
				std::cin >> user_choice;
				break;
		}
	}

	std::cout << "\nTHANKS FOR USING OUR PROGRAM!" << std::endl;
    system("pause");
}

void printMenuOptions()
{
	std::cout <<
		"\n|_Enable options_|\n\n" <<
		"[1] Print all Trips\n" <<
		"[2] Edit Trip\n"<<
		"[3] Add Trip\n" <<
		"[4] Exit\n"<< 
		"\nEnter your choice number: ";
}

void addTrip(std::vector<Trip>& list_to_add_trip)
{
	int trip_id = 0;
	std::string trip_destination = "", full_date = "";
	Trip trip_to_add;
	Date new_trip_date;

	std::cout << "*ID must be more than 0 and not equal to exist id*\nEnter Trip ID: ";
	std::cin >> trip_id;
	while (trip_id <= 0 || doesTripExist(list_to_add_trip, trip_id))
	{
		std::cout << "Incorrect ID, re-enter: ";
		std::cin >> trip_id;
	}

	std::cout << "\nEnter trip destination name: ";
	std::cin >> trip_destination;
	while (trip_destination == "" || trip_destination == " ")
	{
		std::cout << "Name cannot be empty: ";
		std::cin >> trip_destination;
	}

	std::cout << "\nTo enter date: write '08082001'\nThat's mean 08/08/2008\nEnter full date by numbers: ";
	std::cin >> full_date;

	// This while will divide date string to 3 numbers
	while (!new_trip_date.isValidDate(std::stoi(full_date.substr(0, 2)),
		std::stoi(full_date.substr(2, 2)), std::stoi(full_date.substr(4, 4))))
	{
		full_date = "";
		std::cout << "Incorrect date! Re-enter: ";
		std::cin >> full_date;
	}

	new_trip_date.setDay(std::stoi(full_date.substr(0, 2)));
	new_trip_date.setMonth(std::stoi(full_date.substr(2, 2)));
	new_trip_date.setYear(std::stoi(full_date.substr(4, 4)));

	trip_to_add.setTripDate(new_trip_date);
	trip_to_add.setTripDestination(trip_destination);
	trip_to_add.setTripNumber(trip_id);

	list_to_add_trip.push_back(trip_to_add);

	std::cout << "\nTrip has been added successfully." << std::endl;
}

bool doesTripExist(std::vector<Trip>& trips, int tripId) 
{
	for (Trip& trip : trips) 
	{
		if (trip.getTripNumber() == tripId)
		{
			return true;
		}
	}
	return false;
}


void printTrips(std::vector<Trip> trips_to_print)
{
	if (trips_to_print.empty())
	{
		std::cout << "\nNo trips to print :/\n";
		return;
	}
	for (Trip& trip : trips_to_print)
		trip.PrintTrip();
}


void editTrip(std::vector<Trip>& trips_to_edit) 
{

	int tripIdToEdit;
	std::cout << "Enter ID of trip you want to edit: ";
	std::cin >> tripIdToEdit;

	if (!doesTripExist(trips_to_edit, tripIdToEdit)) {
		std::cout << "Trip with ID " << tripIdToEdit << " does not exist." << std::endl;
		return;
	}


	Trip* tripToEdit = nullptr;
	for (Trip& trip : trips_to_edit) {
		if (trip.getTripNumber() == tripIdToEdit) {
			tripToEdit = &trip;
			break;
		}
	}


	int option = 0;
	std::cout << "What do you want to edit?" << std::endl;
	std::cout << "1. Trip number" << std::endl;
	std::cout << "2. Trip destination" << std::endl;
	std::cout << "3. Trip date" << std::endl;
	std::cout << "Enter your choice: ";
	std::cin >> option;

	
	std::string new_date, new_destination;
	int new_id = 0, day, month, year;

	switch (option)
	{
		case 1:
			std::cout << "Enter new trip number: ";
			std::cin >> new_id;
			tripToEdit->setTripNumber(new_id);
			break;
		case 2:
			std::cout << "Enter new trip destination: ";
			std::cin >> new_destination;
			tripToEdit->setTripDestination(new_destination);
			break;
		case 3:
			std::cout << "*To enter date : write '08082001'\nThat's mean 08/08/2008*\nEnter date: ";
			std::cin >> new_date;

			day = std::stoi(new_date.substr(0, 2));
			month = std::stoi(new_date.substr(2, 2));
			year = std::stoi(new_date.substr(4, 4));

			tripToEdit->getTripDate().setDay(day);
			tripToEdit->getTripDate().setMonth(month);
			tripToEdit->getTripDate().setYear(year);
			break;
			break;
		default:
			std::cout << "Invalid option." << std::endl;
			break;
	}

	std::cout << "\nTrip has been edited successfully." << std::endl;
}

